# Realtime Chat Application

## Introduction
In this project, we will create a full Realtime Chat Application. We're going to use  React on the front end, with NodeJS + Socket.io web socket library on the back end. 


Setup:
- run ```npm i && npm start``` for both client and server side to start the development server

work division:
we sat together and worked equally as we live in same room. Both front-end and back-end development done mutually and helped each other to solve the challanges we faced. 
Vedio Link : https://drive.google.com/file/d/11b-oQ7kmhPeqB5O2Jp-L_j14nJgBVVPP/view?usp=sharing

Group Members:
Danish Hafeez
Syed Hurera Ali
