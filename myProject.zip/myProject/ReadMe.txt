# Realtime Chat Application

## Introduction
In this project, we will create a full Realtime Chat Application. We're going to use  React on the front end, with NodeJS + Socket.io web socket library on the back end. 


Setup:
- run ```npm i && npm start``` for both client and server side to start the development server
